echo "Starting IMS Init"
cp ./resolv.conf /etc/resolv.conf
/etc/init.d/bind9 stop
/etc/init.d/bind9 start
sleep 1
/etc/init.d/mysql stop
/etc/init.d/mysql start
sleep 1
modprobe xt_RTPENGINE
sleep 2
iptables -I INPUT -p udp -j RTPENGINE --id 0
sleep 1
/usr/sbin/rtpengine --table=0 --interface=192.168.99.52 --listen-ng=127.0.0.1:2223 --tos=184 --pidfile=/var/run/rtpengine.pid --no-fallback
sleep 1
mkdir /var/run/kamailio_pcscf/
mkdir /var/run/kamailio_icscf/
mkdir /var/run/kamailio_scscf/


echo "End IMS Init"
